﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Media
{
    public partial class Form1 : Form
    {

        double n1,n2,n3;
        double media=0;
        int op=0;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

            if (textBox3.Text != "")
            {
                if (double.Parse(textBox3.Text) > 0 || double.Parse(textBox3.Text) <= 10)
                {
                    n1 = double.Parse(textBox3.Text);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;

                if (op == 1)
                {
                    op = 0;
                    media = (n1 + n2 + n3) / 3;
                }

                if (op == 2)
                {
                    op = 0;
                    media = (n1 * 0.3) + (n2 * 0.3) + (n3 * 0.4);
                }

            if (checkBox1.Checked)
            {
                label5.Text = "N1 vale " + n1 + ",\nN2 vale " + n2 + " e\nN3 vale " + n3 + "\nmedia = " + media;
            }
            else
            {
                label5.Text = media.ToString();
            }

        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            op = 1;
        }

        private void radioButton2_Click(object sender, EventArgs e)
        {
            op = 2;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
            label5.Text = "0";
            op = 0;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            checkBox1.Checked = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                if (double.Parse(textBox2.Text) > 0 && double.Parse(textBox2.Text) <= 10)
                {
                    n2 = double.Parse(textBox2.Text);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (double.Parse(textBox1.Text) > 0 && double.Parse(textBox1.Text) <= 10)
                {
                    n3 = double.Parse(textBox1.Text);
                }
            }
        }
    }
}
