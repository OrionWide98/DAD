﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataArquivo
{
    public partial class Form2 : Form
    {
        int op = 0;

        public Form2()
        {
            InitializeComponent();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            string nome_arq = monthCalendar1.SelectionRange.Start.ToLongDateString();
            if(nome_arq == ("D:\\" + nome_arq + ".txt"))
            {
                
            }

            textBox1.Text = monthCalendar1.SelectionRange.Start.ToLongDateString();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            op = 3;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            op = 5;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            op = 7;
        }

        private void label9_Click(object sender, EventArgs e)
        {
            op = 9;
        }

        private void label11_Click(object sender, EventArgs e)
        {
            op = 11;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (op == 3)
            {
                label3.Text = textBox2.Text;
                label3.Enabled = false;
            }
            else if (op == 5)
            {
                label5.Text = textBox2.Text;
                label5.Enabled = false;
            }
            else if (op == 7)
            {
                label7.Text = textBox2.Text;
                label7.Enabled = false;
            }
            else if (op == 9)
            {
                label9.Text = textBox2.Text;
                label9.Enabled = false;
            }
            else if (op == 11)
            {
                label11.Text = textBox2.Text;
                label11.Enabled = false;
            }
            else MessageBox.Show("Escolha um horário", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nome_arq = monthCalendar1.SelectionRange.Start.ToLongDateString();
            StreamWriter arquivo;
            if (System.IO.File.Exists("D:\\" + nome_arq + ".txt")) File.Delete("D:\\" + nome_arq + ".txt");

            arquivo = new StreamWriter("D:\\" + nome_arq + ".txt");

            foreach(Label controle in tableLayoutPanel1.Controls)
            {
                arquivo.WriteLine(controle.Text);
            }

            arquivo.Close();
            MessageBox.Show("Arquivo Gravado com Sucesso!", "Finalizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
