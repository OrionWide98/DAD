﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDIForms
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float calc;
            try
            {
                if(comboBox1.Text == "Frasco de 500ml")
                {
                    calc = float.Parse(textBox1.Text) * 5;
                    label4.Text = calc.ToString("0.00");
                }
                else if(comboBox1.Text == "Frasco de 1L")
                {
                    calc = float.Parse(textBox1.Text) * 10;
                    label4.Text = calc.ToString("0.00");
                }
                else
                {
                    MessageBox.Show("Selecione um dos frascos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch(FormatException)
            {
                MessageBox.Show("Valor inválido ou vazio");
            }
            finally
            {
                MessageBox.Show("Cálculo encerrado!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = comboBox1.Text = label4.Text = "";
        }
    }
}
