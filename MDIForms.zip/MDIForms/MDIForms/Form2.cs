﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDIForms
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float calc;
            try
            {
                if (radioButton1.Checked)
                {
                    calc = (float.Parse(textBox1.Text)) * float.Parse(textBox3.Text);
                    label5.Text = calc.ToString("0.00");
                }
                else if (radioButton2.Checked)
                {
                    calc = (float.Parse(textBox2.Text)) * float.Parse(textBox3.Text);
                    label5.Text = calc.ToString("0.00");
                }
                else
                {
                    MessageBox.Show("Selecione um combustível!", "Atanção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (FormatException b)
            {
                MessageBox.Show(b.StackTrace);
                //   MessageBox.Show("Não deixe campos vazios/inválidos");
            }
            finally
            {
                MessageBox.Show("Calculo finalizado!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = label5.Text = "";
            radioButton1.Checked = radioButton2.Checked = false;
        }
    }
}
